طريقة التشغيل:

1- أنشئ بوت تيليجرام عبر BotFather
2- ضع BOT TOKEN داخل:
PUT_YOUR_BOT_TOKEN

3- ضع CHAT ID داخل:
PUT_YOUR_CHAT_ID

4- ارفع الملفات على GitHub Pages أو Netlify

عند الضغط على أي زر طلب:
- يصلك إشعار تيليجرام
- ثم يفتح واتساب الموزع تلقائيًا
